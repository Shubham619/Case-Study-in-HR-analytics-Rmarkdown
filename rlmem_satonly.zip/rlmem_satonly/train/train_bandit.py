
import random, json
from collections import defaultdict
from env.union_env import UnionEnv

def main():
    env = UnionEnv()
    a = defaultdict(lambda:1.0)
    b = defaultdict(lambda:1.0)
    rng = random.Random(0)

    for ep in range(50):
        env.reset(seed=ep)
        for _ in range(5):
            aid = max(range(env.num_actions()),
                      key=lambda i: rng.betavariate(a[i], b[i]))
            before = env.first_error_time is None
            res = env.step(aid)
            r = 10*res.new_sigs + (50 if res.errors and before else 0)
            (a if r>0 else b)[aid] += 1

    means = {i:a[i]/(a[i]+b[i]) for i in range(env.num_actions())}
    ranked = sorted(means, key=means.get, reverse=True)
    with open("out_policy.json","w") as f:
        json.dump({"actions": ranked[:3]}, f)
    print("saved out_policy.json")

if __name__ == "__main__":
    main()
