
from backend.backend_base import ErrorEvent
from backend.fault_models import u32

def sat_fill_verify(backend, base, size, vals, busshift, invert):
    words = size // 4
    errors = []
    for w in range(words):
        v = vals[(w >> busshift) % len(vals)]
        if invert: v = u32(~v)
        backend.write32(base + w*4, v)
    for w in range(words):
        exp = vals[(w >> busshift) % len(vals)]
        if invert: exp = u32(~exp)
        addr = base + w*4
        got = backend.read32(addr)
        if got != exp:
            errors.append(ErrorEvent(addr, exp, got, u32(exp ^ got),
                                     backend.fault.last_fault_type))
    return errors
