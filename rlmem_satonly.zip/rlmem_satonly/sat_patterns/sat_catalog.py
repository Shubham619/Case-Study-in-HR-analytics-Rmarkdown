
PATTERNS = {
    "OneZero": [0x0, 0xffffffff],
    "FiveA": [0x55555555, 0xaaaaaaaa],
}

BUSSHIFT = {32:0, 64:1}

def variants():
    out = []
    for name, vals in PATTERNS.items():
        for bw in (32, 64):
            for inv in (0, 1):
                out.append({
                    "variant_name": f"{name}{'~' if inv else ''}{bw}",
                    "vals": vals,
                    "busshift": BUSSHIFT[bw],
                    "invert": bool(inv),
                })
    return out
