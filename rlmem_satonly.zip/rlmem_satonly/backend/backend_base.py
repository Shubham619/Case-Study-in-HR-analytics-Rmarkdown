
from dataclasses import dataclass

@dataclass
class ErrorEvent:
    addr: int
    expected: int
    observed: int
    bitmask: int
    fault_type: str
