
import numpy as np
from backend.fault_models import u32

class NumpyFaultBackend:
    def __init__(self, bytes_size, fault):
        self.mem = np.zeros(bytes_size//4, dtype=np.uint32)
        self.fault = fault
        self.time = 0

    def write32(self, addr, val):
        idx = (addr >> 2) % self.mem.size
        self.mem[idx] = u32(val)
        self.time += 1

    def read32(self, addr):
        idx = (addr >> 2) % self.mem.size
        self.time += 1
        return int(self.fault.apply(idx, int(self.mem[idx])))
