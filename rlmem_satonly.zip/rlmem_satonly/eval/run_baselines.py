
from env.union_env import UnionEnv
import random

def main():
    env = UnionEnv()
    env.reset(0)
    for _ in range(5):
        env.step(random.randrange(env.num_actions()))
    print("random:", env.first_error_time, len(env.seen))

if __name__ == "__main__":
    main()
