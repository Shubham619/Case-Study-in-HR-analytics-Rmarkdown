
# rlmem-satonly

SAT / GSAT-only RL prototype for **fast failure discovery**.

- Uses GSAT-style patterns
- Python DRAM fault simulator
- Bandit RL learns patterns that discover **new failures faster**

Run:
  python -m eval.run_baselines
  python -m train.train_bandit
  python -m eval.eval_policy
