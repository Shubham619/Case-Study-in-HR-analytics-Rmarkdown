# sat_runner.py
from backend.backend_base import ErrorEvent
from backend.fault_models import u32

def sat_fill_verify(backend, base, size, vals, busshift, invert):
    words = size // 4
    errors = []
    
    # FILL PHASE
    for w in range(words):
        # FIX: Remove busshift from index calculation to ensure patterns 
        # cycle correctly (e.g., A, B, A, B...) instead of (A, A, B, B...)
        # The busshift in catalog likely implied data width, but 
        # the write32 interface requires sequential 32-bit chunks.
        v = vals[w % len(vals)]
        
        if invert: v = u32(~v)
        backend.write32(base + w*4, v)
        
    # VERIFY PHASE
    for w in range(words):
        exp = vals[w % len(vals)]
        if invert: exp = u32(~exp)
        addr = base + w*4
        got = backend.read32(addr)
        
        if got != exp:
            errors.append(ErrorEvent(addr, exp, got, u32(exp ^ got),
                                     backend.fault.last_fault_type))
    return errors