import numpy as np
import random
import torch
import torch.nn as nn
import torch.optim as optim

# --- PHASE 1: THOMPSON SAMPLING BANDIT ---
class LegacyAgent:
    def __init__(self, n_patterns):
        # Beta Distribution Parameters (Alpha=Success, Beta=Failure)
        self.alpha = np.ones(n_patterns) 
        self.beta = np.ones(n_patterns)  

    def select_pattern(self):
        # Sample from Beta distribution for each arm
        samples = [np.random.beta(a, b) for a, b in zip(self.alpha, self.beta)]
        return np.argmax(samples)

    def update(self, pat_id, reward):
        # If reward > 0, we found a bug -> Increase Alpha
        if reward > 0: 
            self.alpha[pat_id] += reward / 100.0
        # If no reward, we wasted time -> Increase Beta
        else: 
            self.beta[pat_id] += 1.0

# --- PHASE 2: DQN FOR TOPOLOGY DISCOVERY ---
class QNetwork(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(QNetwork, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, output_dim)
        )

    def forward(self, x):
        return self.fc(x)

class DiscoveryAgent:
    def __init__(self, addr_width=16):
        # Action Space: All unique pairs of bit swaps (0,1), (0,2)...
        self.actions = [(i, j) for i in range(addr_width) for j in range(addr_width) if i < j]
        self.n_actions = len(self.actions)
        
        # Simple DQN with dummy state input (Stateless Context)
        self.model = QNetwork(1, self.n_actions)
        self.opt = optim.Adam(self.model.parameters(), lr=0.005)
        self.epsilon = 0.3 # Exploration Rate

    def select_action(self):
        # Epsilon-Greedy Policy
        if random.random() < self.epsilon:
            return random.choice(self.actions)
        
        with torch.no_grad():
            # Input is constant [1.0] because environment is partially observable via reward
            q = self.model(torch.FloatTensor([1.0]))
            idx = torch.argmax(q).item()
            return self.actions[idx]

    def update(self, action_pair, reward):
        idx = self.actions.index(action_pair)
        target = torch.tensor([reward], dtype=torch.float32)
        
        # Single Step Update
        pred = self.model(torch.FloatTensor([1.0]))[idx]
        loss = (pred - target) ** 2
        
        self.opt.zero_grad()
        loss.backward()
        self.opt.step()
        
        # Decay Epsilon
        if self.epsilon > 0.05:
            self.epsilon *= 0.999
