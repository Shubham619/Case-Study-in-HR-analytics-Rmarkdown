import ctypes
import os
import random
from .gsat_db import GSAT_Library

# Load Ramulator2 Wrapper Library
try:
    # Path to the compiled wrapper in the build directory
    lib_path = os.path.abspath("./build/libramulator_wrapper.so")
    _lib = ctypes.CDLL(lib_path)
    
    # Define C++ Function Signatures
    _lib.init_simulator.argtypes = [ctypes.c_char_p]
    _lib.step_simulator.argtypes = [ctypes.c_int, ctypes.c_long, ctypes.c_int]
    _lib.step_simulator.restype = ctypes.c_int
    HAS_SIM = True
    print("[Environment] Ramulator2 Library Loaded Successfully.")
except OSError as e:
    print(f"[CRITICAL ERROR] Could not load Ramulator2 Wrapper: {e}")
    print("Ensure you have run 'bash build_lib.sh' successfully.")
    HAS_SIM = False

class DramEnv:
    def __init__(self, config_file="configs/ddr4_config.yaml"):
        self.gsat = GSAT_Library()
        
        if HAS_SIM:
            # Initialize Ramulator2 with the YAML config
            c_config = ctypes.c_char_p(config_file.encode('utf-8'))
            _lib.init_simulator(c_config)
            
        # --- BS-LFSR STATE (Phase 2 Discovery) ---
        # Initial Seed
        self.lfsr_state = 0xACE1
        # Mapping for Bit Swapping (Identity initially)
        self.lfsr_mapping = list(range(16)) 
        
        self.fault_history = set()

    # --- PHASE 2: BS-LFSR LOGIC (Fully Implemented) ---
    def get_bs_lfsr_addr(self):
        """
        Generates next address using Bit-Swapping LFSR.
        1. Linear Feedback Shift (Randomness)
        2. Bit Swapping (Topology Mapping)
        """
        # 1. Standard LFSR Step (16-bit tap)
        self.lfsr_state ^= (self.lfsr_state << 7) & 0xFFFF
        self.lfsr_state ^= (self.lfsr_state >> 9)
        self.lfsr_state ^= (self.lfsr_state << 8) & 0xFFFF
        self.lfsr_state &= 0xFFFF
        
        # 2. Bit Swapping Logic
        swapped_addr = 0
        for out_bit, in_bit in enumerate(self.lfsr_mapping):
            # Check if the 'in_bit' of state is 1
            if (self.lfsr_state >> in_bit) & 1:
                # Set the 'out_bit' of result to 1
                swapped_addr |= (1 << out_bit)
        return swapped_addr

    def swap_bits(self, bit_a, bit_b):
        """Agent Action: Modify the topology mapping"""
        if bit_a < 16 and bit_b < 16:
            self.lfsr_mapping[bit_a], self.lfsr_mapping[bit_b] = \
            self.lfsr_mapping[bit_b], self.lfsr_mapping[bit_a]

    # --- EXECUTION CORE ---
    def step(self, phase, action_id):
        """
        Executes a step on the simulator.
        Phase 1 Action: pattern_id (0-9)
        Phase 2 Action: (bit_a, bit_b) tuple to swap
        """
        
        # 1. Determine Address & Data based on Phase
        if phase == 1:
            # Legacy: Linear Random Address, Specific Pattern Data
            addr = random.randint(0, 0xFFFF)
            data = self.gsat.get_data_for_addr(action_id, addr)
        else:
            # Discovery: Swapped Topology Address, Random Data
            b1, b2 = action_id
            self.swap_bits(b1, b2)
            addr = self.get_bs_lfsr_addr()
            data = random.randint(0, 0xFFFFFFFF)

        # 2. Run on C++ Simulator
        res = 0
        if HAS_SIM:
            # Write Step
            _lib.step_simulator(1, addr, data) 
            # Read Step (Verify)
            res = _lib.step_simulator(0, addr, data) 
        else:
            res = 0 # Mock if sim missing

        # 3. Reward Calculation
        reward = 0
        is_new = False
        
        if res > 0: # Fault Detected
            f_key = (addr, res)
            if f_key not in self.fault_history:
                self.fault_history.add(f_key)
                is_new = True
                
                # Weighted Rewards based on Fault Severity
                if res == 10: reward = 1000   # Hammer (Critical)
                elif res in [2,5,6,7]: reward = 500 # Coupling/Destructive
                else: reward = 100            # Single Cell
                
        return reward, is_new, res
