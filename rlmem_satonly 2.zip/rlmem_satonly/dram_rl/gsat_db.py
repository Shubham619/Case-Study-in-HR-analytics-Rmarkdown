"""
gsat_db.py
Implements the algorithmic logic for Phase 1 Legacy Patterns.
Represents the 'Full GSAT Suite' compressed into algorithms.
"""

class GSAT_Library:
    def __init__(self):
        # The Master List of Patterns (ID -> Name)
        self.patterns = {
            0: "Solid_Zero",
            1: "Solid_One",
            2: "Checkerboard",
            3: "Inv_Checkerboard",
            4: "Walking_One_Left",
            5: "Walking_Zero_Left",
            6: "Random_Noise",
            7: "Block_Row_Stripe",
            8: "Hammer_Test_Simple",
            9: "Address_Complement"
        }
    
    def get_data_for_addr(self, pat_id, addr):
        """Generates data on-the-fly (Algorithmic)"""
        # 0: Solid 0
        if pat_id == 0: return 0x00000000
        # 1: Solid 1
        if pat_id == 1: return 0xFFFFFFFF
        # 2: Checkerboard (0x55 / 0xAA)
        if pat_id == 2: return 0x55555555 if (addr % 2) == 0 else 0xAAAAAAAA
        # 3: Inverse Checkerboard
        if pat_id == 3: return 0xAAAAAAAA if (addr % 2) == 0 else 0x55555555
        # 4: Walking One
        if pat_id == 4: return (1 << (addr % 32)) 
        # 5: Walking Zero
        if pat_id == 5: return ~(1 << (addr % 32)) & 0xFFFFFFFF
        # 6: Pseudo Random
        if pat_id == 6: return (addr * 12345 + 6789) & 0xFFFFFFFF
        # 7: Block Stripe (Row based)
        if pat_id == 7: return 0xFFFFFFFF if ((addr >> 4) % 2) == 0 else 0x00000000
        # 8: Hammer Helper (Alternating)
        if pat_id == 8: return 0xFFFFFFFF if (addr % 2) == 0 else 0x00000000
        # 9: Address Complement
        if pat_id == 9: return (~addr) & 0xFFFFFFFF
        
        # Default fallback
        return 0x00000000

    def get_total_count(self):
        return len(self.patterns)
