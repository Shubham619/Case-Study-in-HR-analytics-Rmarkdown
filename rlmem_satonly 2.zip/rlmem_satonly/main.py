from dram_rl.environment import DramEnv
from dram_rl.agents import LegacyAgent, DiscoveryAgent
import time
import numpy as np

def main():
    print("=== STARTING END-TO-END DRAM RL SYSTEM (Ramulator2) ===")
    
    # 1. Initialize Environment
    # Ensure configs/ddr4_config.yaml exists
    env = DramEnv(config_file="configs/ddr4_config.yaml")
    
    # 2. Initialize Agents
    phase1 = LegacyAgent(n_patterns=10) # 10 GSAT Patterns
    phase2 = DiscoveryAgent(addr_width=16) # 16-bit Address BS-LFSR
    
    # --- PHASE 1: LEGACY OPTIMIZATION ---
    print("\n[PHASE 1] Optimizing Legacy GSAT Patterns (Bandit)...")
    start_t = time.time()
    
    for i in range(2000):
        # Bandit selects pattern
        pat_id = phase1.select_pattern()
        
        # Execute in Ramulator2
        reward, new, code = env.step(phase=1, action_id=pat_id)
        
        # Update Bandit
        phase1.update(pat_id, reward)
        
        if i % 500 == 0:
            print(f"  [Step {i}] Faults Found: {len(env.fault_history)}")

    best_pat = np.argmax(phase1.alpha)
    print(f"Phase 1 Complete. Best Pattern ID: {best_pat} ({env.gsat.patterns[best_pat]})")
    print(f"Total Faults from Legacy: {len(env.fault_history)}")

    # --- PHASE 2: TOPOLOGY DISCOVERY ---
    print("\n[PHASE 2] Starting BS-LFSR Topology Discovery (DQN)...")
    initial_faults = len(env.fault_history)
    hammer_count = 0
    
    for i in range(2000):
        # DQN selects bit-swap topology
        swap_pair = phase2.select_action()
        
        # Execute in Ramulator2
        reward, new, code = env.step(phase=2, action_id=swap_pair)
        
        # Update DQN
        phase2.update(swap_pair, reward)
        
        if new:
            if code == 10:
                hammer_count += 1
                print(f"  [CRITICAL] Phase 2 Discovered RowHammer Sequence at Step {i}!")
            elif code == 6:
                print(f"  [INFO] Phase 2 Discovered TCF (Transition Fault) at Step {i}")

    # --- FINAL REPORT ---
    new_faults = len(env.fault_history) - initial_faults
    
    print("\n" + "="*40)
    print("       FINAL EVALUATION REPORT       ")
    print("="*40)
    print(f"Total Unique Faults Detected: {len(env.fault_history)}")
    print(f"  - From Phase 1 (Legacy):    {initial_faults}")
    print(f"  - From Phase 2 (New):       {new_faults}")
    print(f"  - RowHammer Incidents:      {hammer_count}")
    print("-" * 40)
    
    if new_faults > 0:
        print("[SUCCESS] The RL Agent successfully discovered hidden defects.")
    else:
        print("[NOTE] No new faults found. Try increasing simulation cycles or fault probabilities.")

if __name__ == "__main__":
    main()
