#include <iostream>
#include <map>
#include <vector>
#include <cstdlib>
#include <ctime>

// --- BRIDGE FUNCTIONS (Linked from bridge.cpp) ---
extern "C" {
    void* make_ramulator_system(const char* config_path);
    bool send_request(void* sys_ptr, long addr, int is_write);
    void tick_system(void* sys_ptr);
}

// --- GLOBAL VARIABLES ---
static void* system_ptr = nullptr;

// Physics Globals
static std::map<long, int> physical_cell_data; 
static std::map<int, int> hammer_counters; 

struct FaultConfig {
    double p_sf = 0.01; 
    double p_rdf = 0.01, p_drdf = 0.01, p_wdf = 0.01;
    double p_tcf = 0.05, p_scf = 0.05, p_dccf = 0.05, p_irf = 0.01, p_icf = 0.05;
    int hammer_thresh = 5;
};
static FaultConfig f_cfg;

extern "C" {

    void init_simulator(const char* config_path) {
        // CALL THE BRIDGE
        system_ptr = make_ramulator_system(config_path);
        
        if (!system_ptr) {
            std::cerr << "[Wrapper Error] Failed to create Ramulator System!" << std::endl;
            exit(1);
        }

        // Reset Physics
        physical_cell_data.clear();
        hammer_counters.clear();
        std::srand(std::time(nullptr));
        
        std::cout << "[Wrapper] Initialized Successfully (Bridge Mode)." << std::endl;
    }

    long get_aggressor(long victim) { return victim ^ 0x1; }

    int check_physics(int type, long addr, int data_in) {
        if ((rand() % 1000000) < (f_cfg.p_sf * 1000000)) {
            physical_cell_data[addr] = rand() % 2; return 1; 
        }

        int curr_val = physical_cell_data[addr];
        long agg_addr = get_aggressor(addr);

        if (type == 0) { // READ
            if ((rand() % 1000000) < (f_cfg.p_rdf * 1000000)) { 
                physical_cell_data[addr] = !curr_val; return 2; 
            }
        } else { // WRITE
            if (curr_val == data_in && (rand() % 1000000) < (f_cfg.p_wdf * 1000000)) { 
                physical_cell_data[addr] = !data_in; return 5; 
            }
        }

        // RowHammer
        int bank = (addr >> 14) & 0xF;
        int row = (addr >> 18) & 0xFFFF;
        int row_id = (bank << 16) | row;
        
        hammer_counters[row_id]++;
        if (hammer_counters[row_id] > f_cfg.hammer_thresh) {
            hammer_counters[row_id] = 0;
            return 10; 
        }

        if (type == 1) physical_cell_data[addr] = data_in;
        return 0; 
    }

    int step_simulator(int type, long addr, int data) {
        if (!system_ptr) return -1;
        
        // Use Bridge to talk to C++ object
        bool accepted = send_request(system_ptr, addr, type);
        tick_system(system_ptr);
        
        if (!accepted) return -1; 
        return check_physics(type, addr, data);
    }
}