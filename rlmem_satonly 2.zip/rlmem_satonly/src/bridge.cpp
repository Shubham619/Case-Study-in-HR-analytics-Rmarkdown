#include "base/base.h"
#include "base/config.h"
#include "memory_system/memory_system.h"
#include "base/factory.h"

// --- THE FIX: GLOBAL TYPE ALIAS ---
// We define the complex template type here, once, at the global scope.
// This prevents the compiler from getting confused inside the function.
using RamulatorFactory = Ramulator::Factory<Ramulator::IMemorySystem>;

extern "C" {
    void* make_ramulator_system(const char* config_path) {
        try {
            YAML::Node config = YAML::LoadFile(config_path);
            
            // Extract params
            std::string impl_name = config["MemorySystem"]["impl"].template as<std::string>();
            YAML::Node mem_config = config["MemorySystem"];
            
            // --- USE THE ALIAS ---
            // Now we just use 'RamulatorFactory' like a normal class.
            // No < > symbols to confuse the compiler here.
            auto& factory = RamulatorFactory::instance();
            
            Ramulator::IMemorySystem* sys = factory.create(impl_name, mem_config, nullptr);
            
            return (void*)sys;
        } catch (...) {
            return nullptr;
        }
    }

    bool send_request(void* sys_ptr, long addr, int is_write) {
        if (!sys_ptr) return false;
        Ramulator::IMemorySystem* sys = (Ramulator::IMemorySystem*)sys_ptr;
        
        Ramulator::Request req(addr, is_write ? Ramulator::Request::Type::Write : Ramulator::Request::Type::Read);
        return sys->send(req);
    }

    void tick_system(void* sys_ptr) {
        if (!sys_ptr) return;
        Ramulator::IMemorySystem* sys = (Ramulator::IMemorySystem*)sys_ptr;
        sys->tick();
    }
}