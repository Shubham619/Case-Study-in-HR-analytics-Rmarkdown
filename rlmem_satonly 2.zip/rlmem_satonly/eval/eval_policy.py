
import json
from env.union_env import UnionEnv

def main():
    pol = json.load(open("out_policy.json"))
    env = UnionEnv()
    env.reset(1)
    for i in range(5):
        env.step(pol["actions"][i % len(pol["actions"])])
    print("policy:", env.first_error_time, len(env.seen))

if __name__ == "__main__":
    main()
