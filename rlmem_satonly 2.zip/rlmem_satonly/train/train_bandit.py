# train_bandit.py
import random, json, math
from collections import defaultdict
from env.union_env import UnionEnv

def main():
    env = UnionEnv()
    num_actions = env.num_actions()
    
    # UCB1 Variables
    # Q: Estimated value of action
    # N: Number of times action was selected
    Q = defaultdict(float)
    N = defaultdict(int)
    total_steps = 0
    
    rng = random.Random(0)

    print(f"Training on {num_actions} actions...")

    for ep in range(100): # Increased episodes for better convergence
        env.reset(seed=ep)
        
        # We allow the agent to take multiple steps per episode
        for step_idx in range(5):
            # UCB Action Selection
            if step_idx < num_actions and total_steps < num_actions:
                # Force exploration of all actions at least once
                aid = total_steps % num_actions
            else:
                # Calculate UCB scores
                best_score = -float('inf')
                aid = -1
                for i in range(num_actions):
                    if N[i] == 0:
                        score = float('inf')
                    else:
                        exploration_weight = 2.0  # Tunable parameter
                        score = Q[i] + exploration_weight * math.sqrt(math.log(total_steps) / N[i])
                    
                    if score > best_score:
                        best_score = score
                        aid = i
            
            # Execute
            before_first_time = env.first_error_time
            res = env.step(aid)
            total_steps += 1
            
            # --- REWARD ENGINEERING ---
            # 1. Coverage Reward: High value for new unique signatures
            r_coverage = 50.0 * res.new_sigs
            
            # 2. TTFF Reward: Heavily reward finding the *first* error of the episode.
            # We want to MINIMIZE time, so we invert the time metric.
            r_ttff = 0.0
            if res.errors and before_first_time is None:
                # Found the first error in this step!
                # res.dt is the time taken in this step.
                # Lower dt = Higher Reward. 
                # Assuming typical step takes ~1000-10000 ticks.
                r_ttff = 100000.0 / (res.dt + 1.0) 
                
                # Bonus flat reward for breaking the system at all
                r_ttff += 200.0 

            reward = r_coverage + r_ttff

            # Update Q-values (Incremental Mean)
            N[aid] += 1
            Q[aid] += (reward - Q[aid]) / N[aid]

    # Output Results
    # Sort by estimated Value (Q)
    ranked = sorted(Q, key=Q.get, reverse=True)
    
    print("\nTop 5 Actions (ID: Score):")
    for aid in ranked[:5]:
        print(f"Action {aid}: {Q[aid]:.2f} (Selected {N[aid]} times)")

    with open("out_policy.json", "w") as f:
        json.dump({"actions": ranked[:3]}, f)
    print("saved out_policy.json")

if __name__ == "__main__":
    main()