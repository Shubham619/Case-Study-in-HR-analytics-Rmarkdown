
import random
from dataclasses import dataclass

def u32(x): return x & 0xffffffff

@dataclass
class FaultConfig:
    seed: int = 0
    stuck_prob: float = 5e-5

class FaultModel:
    def __init__(self, cfg, mem_words):
        self.rng = random.Random(cfg.seed)
        self.last_fault_type = "none"
        self.stuck = {}
        for i in range(mem_words):
            if self.rng.random() < cfg.stuck_prob:
                self.stuck[i] = self.rng.randrange(32)

    def apply(self, idx, val):
        self.last_fault_type = "none"
        if idx in self.stuck:
            self.last_fault_type = "stuck"
            return u32(val | (1 << self.stuck[idx]))
        return val
