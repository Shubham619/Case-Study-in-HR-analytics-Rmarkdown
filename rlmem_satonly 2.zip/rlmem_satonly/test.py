
from __future__ import annotations
import argparse
import json
import math
import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Callable
from array import array

# ----------------------------
# 1. Utilities
# ----------------------------

def u32(x: int) -> int:
    """Ensure 32-bit unsigned integer wrapping."""
    return x & 0xFFFFFFFF

def popcount32(x: int) -> int:
    """Count set bits."""
    if hasattr(int, "bit_count"):
        return (x & 0xFFFFFFFF).bit_count()
    return bin(x & 0xFFFFFFFF).count('1')

# ----------------------------
# 2. EXACT GSAT PATTERN DATA
# ----------------------------

# Data arrays transcribed from pattern.cc

walkingOnes_data = [
  0x00000001, 0x00000002, 0x00000004, 0x00000008,
  0x00000010, 0x00000020, 0x00000040, 0x00000080,
  0x00000100, 0x00000200, 0x00000400, 0x00000800,
  0x00001000, 0x00002000, 0x00004000, 0x00008000,
  0x00010000, 0x00020000, 0x00040000, 0x00080000,
  0x00100000, 0x00200000, 0x00400000, 0x00800000,
  0x01000000, 0x02000000, 0x04000000, 0x08000000,
  0x10000000, 0x20000000, 0x40000000, 0x80000000,
  0x40000000, 0x20000000, 0x10000000, 0x08000000,
  0x04000000, 0x02000000, 0x01000000, 0x00800000,
  0x00400000, 0x00200000, 0x00100000, 0x00080000,
  0x00040000, 0x00020000, 0x00010000, 0x00008000,
  0x00004000, 0x00002000, 0x00001000, 0x00000800,
  0x00000400, 0x00000200, 0x00000100, 0x00000080,
  0x00000040, 0x00000020, 0x00000010, 0x00000008,
  0x00000004, 0x00000002, 0x00000001, 0x00000000
]

walkingInvOnes_data = [
  0x00000001, 0xfffffffe, 0x00000002, 0xfffffffd,
  0x00000004, 0xfffffffb, 0x00000008, 0xfffffff7,
  0x00000010, 0xffffffef, 0x00000020, 0xffffffdf,
  0x00000040, 0xffffffbf, 0x00000080, 0xffffff7f,
  0x00000100, 0xfffffeff, 0x00000200, 0xfffffdff,
  0x00000400, 0xfffffbff, 0x00000800, 0xfffff7ff,
  0x00001000, 0xffffefff, 0x00002000, 0xffffdfff,
  0x00004000, 0xffffbfff, 0x00008000, 0xffff7fff,
  0x00010000, 0xfffeffff, 0x00020000, 0xfffdffff,
  0x00040000, 0xfffbffff, 0x00080000, 0xfff7ffff,
  0x00100000, 0xffefffff, 0x00200000, 0xffdfffff,
  0x00400000, 0xffbfffff, 0x00800000, 0xff7fffff,
  0x01000000, 0xfeffffff, 0x02000000, 0xfdffffff,
  0x04000000, 0xfbffffff, 0x08000000, 0xf7ffffff,
  0x10000000, 0xefffffff, 0x20000000, 0xdfffffff,
  0x40000000, 0xbfffffff, 0x80000000, 0x7fffffff,
  0x40000000, 0xbfffffff, 0x20000000, 0xdfffffff,
  0x10000000, 0xefffffff, 0x08000000, 0xf7ffffff,
  0x04000000, 0xfbffffff, 0x02000000, 0xfdffffff,
  0x01000000, 0xfeffffff, 0x00800000, 0xff7fffff,
  0x00400000, 0xffbfffff, 0x00200000, 0xffdfffff,
  0x00100000, 0xffefffff, 0x00080000, 0xfff7ffff,
  0x00040000, 0xfffbffff, 0x00020000, 0xfffdffff,
  0x00010000, 0xfffeffff, 0x00008000, 0xffff7fff,
  0x00004000, 0xffffbfff, 0x00002000, 0xffffdfff,
  0x00001000, 0xffffefff, 0x00000800, 0xfffff7ff,
  0x00000400, 0xfffffbff, 0x00000200, 0xfffffdff,
  0x00000100, 0xfffffeff, 0x00000080, 0xffffff7f,
  0x00000040, 0xffffffbf, 0x00000020, 0xffffffdf,
  0x00000010, 0xffffffef, 0x00000008, 0xfffffff7,
  0x00000004, 0xfffffffb, 0x00000002, 0xfffffffd,
  0x00000001, 0xfffffffe, 0x00000000, 0xffffffff
]

walkingZeros_data = [
  0xfffffffe, 0xfffffffd, 0xfffffffb, 0xfffffff7,
  0xffffffef, 0xffffffdf, 0xffffffbf, 0xffffff7f,
  0xfffffeff, 0xfffffdff, 0xfffffbff, 0xfffff7ff,
  0xffffefff, 0xffffdfff, 0xffffbfff, 0xffff7fff,
  0xfffeffff, 0xfffdffff, 0xfffbffff, 0xfff7ffff,
  0xffefffff, 0xffdfffff, 0xffbfffff, 0xff7fffff,
  0xfeffffff, 0xfdffffff, 0xfbffffff, 0xf7ffffff,
  0xefffffff, 0xdfffffff, 0xbfffffff, 0x7fffffff,
  0xbfffffff, 0xdfffffff, 0xefffffff, 0xf7ffffff,
  0xfbffffff, 0xfdffffff, 0xfeffffff, 0xff7fffff,
  0xffbfffff, 0xffdfffff, 0xffefffff, 0xfff7ffff,
  0xfffbffff, 0xfffdffff, 0xfffeffff, 0xffff7fff,
  0xffffbfff, 0xffffdfff, 0xffffefff, 0xfffff7ff,
  0xfffffbff, 0xfffffdff, 0xfffffeff, 0xffffff7f,
  0xffffffbf, 0xffffffdf, 0xffffffef, 0xfffffff7,
  0xfffffffb, 0xfffffffd, 0xfffffffe, 0xffffffff
]

# Structure definition mimicking GSAT PatternData
@dataclass
class GsatPattern:
    name: str
    data: List[int]
    weights: List[int] # Weights for [32, 64, 128, 256]

GSAT_PATTERNS = [
    GsatPattern("walkingOnes",    walkingOnes_data,    [1, 1, 2, 1]),
    GsatPattern("walkingInvOnes", walkingInvOnes_data, [2, 2, 5, 5]),
    GsatPattern("walkingZeros",   walkingZeros_data,   [1, 1, 2, 1]),
    GsatPattern("OneZero",        [0x00000000, 0xffffffff], [5, 5, 15, 5]),
    GsatPattern("JustZero",       [0x00000000, 0x00000000], [2, 0, 0, 0]),
    GsatPattern("JustOne",        [0xffffffff, 0xffffffff], [2, 0, 0, 0]),
    GsatPattern("JustFive",       [0x55555555, 0x55555555], [2, 0, 0, 0]),
    GsatPattern("JustA",          [0xaaaaaaaa, 0xaaaaaaaa], [2, 0, 0, 0]),
    GsatPattern("FiveA",          [0x55555555, 0xaaaaaaaa], [1, 1, 1, 1]),
    GsatPattern("FiveA8",         [0x5aa5a55a, 0xa55a5aa5, 0xa55a5aa5, 0x5aa5a55a], [1, 1, 1, 1]),
    GsatPattern("Long8b10b",      [0x16161616, 0x16161616], [2, 0, 0, 0]),
    GsatPattern("Short8b10b",     [0xb5b5b5b5, 0xb5b5b5b5], [2, 0, 0, 0]),
    GsatPattern("Checker8b10b",   [0xb5b5b5b5, 0x4a4a4a4a], [1, 0, 0, 1]),
    GsatPattern("Five7",          [0x55555557, 0x55575555], [0, 2, 0, 0]),
    GsatPattern("Zero2fd",        [0x00020002, 0xfffdfffd], [0, 2, 0, 0]),
]

BUSSHIFT_MAP = {32: 0, 64: 1, 128: 2, 256: 3}
WIDTHS = [32, 64, 128, 256]

def build_sat_variants() -> List[Dict]:
    """
    Expands GSAT patterns into RL actions.
    Respects the GSAT weights: if weight is 0 for a width, the action is skipped.
    """
    out = []
    for p in GSAT_PATTERNS:
        for i, bw in enumerate(WIDTHS):
            weight = p.weights[i]
            if weight > 0:
                # GSAT PatternList::Initialize creates both Normal and Inverted
                # for every enabled pattern.
                for inv in (False, True):
                    out.append({
                        "pattern": p.name,
                        "vals": p.data,
                        "buswidth": bw,
                        "busshift": BUSSHIFT_MAP[bw],
                        "invert": inv,
                        "variant_name": f"{p.name}{'~' if inv else ''}_{bw}",
                    })
    return out

# ----------------------------
# 3. Super Fault Model
# ----------------------------

@dataclass
class FaultConfig:
    seed: int = 0
    
    # Hard Faults (Permanent)
    stuck_prob: float = 2e-6          # CE
    burst_prob: float = 2e-7          # UE (Cluster)
    
    # Soft Faults (Transient)
    intermittent_prob: float = 1e-8
    
    # Retention
    retention_prob: float = 2e-6
    retention_flip_after: int = 40_000 
    
    # Hammer
    cacheline_bytes: int = 64
    hammer_threshold: int = 6000      
    hammer_flip_prob: float = 2e-3    

class FaultModel:
    def __init__(self, cfg: FaultConfig, mem_words: int):
        self.cfg = cfg
        self.rng = random.Random(cfg.seed)
        self.mem_words = mem_words
        self.time = 0
        self.last_fault_type = "none"

        self.stuck: Dict[int, int] = {}
        self.stuck_val: Dict[int, int] = {}
        self.retention: Dict[int, Tuple[int, int]] = {}
        self.cl_access: Dict[int, int] = {}

        # Inject Static Faults
        for i in range(mem_words):
            if self.rng.random() < cfg.stuck_prob:
                bit = self.rng.randrange(32)
                self._add_stuck(i, bit)

            if self.rng.random() < cfg.burst_prob:
                bit_start = self.rng.randrange(28) 
                width = self.rng.randint(2, 4)
                for b in range(bit_start, bit_start + width):
                    self._add_stuck(i, b)
            
            if self.rng.random() < cfg.retention_prob:
                bit = self.rng.randrange(32)
                flip_t = max(1, cfg.retention_flip_after + self.rng.randint(-5000, 5000))
                self.retention[i] = (bit, flip_t)

    def _add_stuck(self, idx, bit):
        mask = self.stuck.get(idx, 0) | (1 << bit)
        self.stuck[idx] = mask
        curr = self.stuck_val.get(idx, 0)
        if self.rng.choice([True, False]):
            curr |= (1 << bit)
        else:
            curr &= ~(1 << bit)
        self.stuck_val[idx] = curr

    def on_time(self, t: int):
        self.time = t

    def on_access(self, addr: int):
        cl = addr // self.cfg.cacheline_bytes
        self.cl_access[cl] = self.cl_access.get(cl, 0) + 1

    def apply_on_read(self, addr: int, idx: int, val: int) -> int:
        self.last_fault_type = "none"
        original_val = val
        v = val

        # 1. Hammer
        cl = addr // self.cfg.cacheline_bytes
        if self.cl_access.get(cl, 0) > self.cfg.hammer_threshold:
            if self.rng.random() < self.cfg.hammer_flip_prob:
                bit = self.rng.randrange(32)
                v ^= (1 << bit)
                self.last_fault_type = "hammer"

        # 2. Retention
        if idx in self.retention:
            bit, flip_t = self.retention[idx]
            if self.time >= flip_t:
                v ^= (1 << bit)
                if self.last_fault_type == "none": 
                    self.last_fault_type = "retention"

        # 3. Intermittent
        if self.rng.random() < self.cfg.intermittent_prob:
            bit = self.rng.randrange(32)
            v ^= (1 << bit)
            if self.last_fault_type == "none":
                self.last_fault_type = "intermittent"

        # 4. Hard Faults
        if idx in self.stuck:
            mask = self.stuck[idx]
            forced = self.stuck_val[idx]
            v = (v & ~mask) | (forced & mask)
            
            if v != original_val:
                if popcount32(mask) > 1:
                    self.last_fault_type = "burst_ue"
                else:
                    self.last_fault_type = "stuck_ce"

        return u32(v)

# ----------------------------
# 4. Backend & Environment
# ----------------------------

@dataclass
class ErrorEvent:
    addr: int
    expected: int
    observed: int
    bitmask: int
    fault_type: str
    is_ue: bool

class DRAMBackend:
    def __init__(self, mem_bytes: int, fault: FaultModel):
        self.mem_words = mem_bytes // 4
        self.mem = array('I', [0] * self.mem_words)
        self.fault = fault
        self.time = 0

    def write32(self, addr: int, val: int):
        idx = (addr >> 2) % self.mem_words
        self.mem[idx] = u32(val)
        self.time += 1
        self.fault.on_time(self.time)
        self.fault.on_access(addr)

    def read32(self, addr: int) -> int:
        idx = (addr >> 2) % self.mem_words
        self.time += 1
        self.fault.on_time(self.time)
        self.fault.on_access(addr)
        raw = int(self.mem[idx])
        return int(self.fault.apply_on_read(addr, idx, raw))

def sat_fill_verify(backend: DRAMBackend, base_addr: int, size_bytes: int,
                    vals: List[int], busshift: int, invert: bool) -> List[ErrorEvent]:
    words = size_bytes // 4
    errors: List[ErrorEvent] = []

    # WRITE
    for w in range(words):
        # GSAT logic: pattern index varies based on bus shift
        pi = (w >> busshift) % len(vals)
        v = vals[pi]
        if invert: v = u32(~v)
        backend.write32(base_addr + w * 4, v)

    # VERIFY
    for w in range(words):
        pi = (w >> busshift) % len(vals)
        exp = vals[pi]
        if invert: exp = u32(~exp)
        addr = base_addr + w * 4
        got = backend.read32(addr)
        
        if got != exp:
            diff = u32(exp ^ got)
            is_ue = popcount32(diff) > 1
            errors.append(ErrorEvent(
                addr=addr,
                expected=exp,
                observed=got,
                bitmask=diff,
                fault_type=backend.fault.last_fault_type,
                is_ue=is_ue
            ))

    return errors

@dataclass
class StepResult:
    dt: int
    errors: int
    new_sigs: int
    ce_count: int
    ue_count: int
    first_error_time: Optional[int]

class SatEnv:
    def __init__(self, mem_mb: int, region_kb: int, seed: int):
        self.mem_bytes = mem_mb * 1024 * 1024
        self.region_bytes = min(region_kb * 1024, self.mem_bytes)
        self.seed = seed
        self.sat_vars = build_sat_variants()
        self.backend: Optional[DRAMBackend] = None
        self.seen_sigs: set = set()
        self.first_error_time: Optional[int] = None

    def reset(self, fault_seed: int, cfg_override: Optional[dict] = None):
        cfg = FaultConfig(seed=fault_seed)
        if cfg_override:
            for k, v in cfg_override.items():
                setattr(cfg, k, v)
        fault = FaultModel(cfg, mem_words=self.mem_bytes // 4)
        self.backend = DRAMBackend(self.mem_bytes, fault)
        self.seen_sigs = set()
        self.first_error_time = None

    def num_actions(self) -> int:
        return len(self.sat_vars)

    def step(self, action_id: int) -> StepResult:
        assert self.backend is not None
        t0 = self.backend.time
        v = self.sat_vars[action_id]
        
        errs = sat_fill_verify(
            self.backend, 0, self.region_bytes,
            v["vals"], v["busshift"], v["invert"]
        )

        new = 0
        ce = 0
        ue = 0
        
        for e in errs:
            if e.is_ue:
                ue += 1
                cat = "UE"
            else:
                ce += 1
                cat = "CE"
            
            sig = (cat, e.fault_type, e.addr // 4096, e.bitmask)
            if sig not in self.seen_sigs:
                self.seen_sigs.add(sig)
                new += 1

        if errs and self.first_error_time is None:
            self.first_error_time = self.backend.time

        return StepResult(
            dt=self.backend.time - t0,
            errors=len(errs),
            new_sigs=new,
            ce_count=ce,
            ue_count=ue,
            first_error_time=self.first_error_time
        )

# ----------------------------
# 5. RL Agent (Thompson Sampling)
# ----------------------------

def bandit_train(episodes: int, steps: int, mem_mb: int, region_kb: int,
                 seed: int, out_path: str, cfg_override: Optional[dict]):
    rng = random.Random(seed)
    env = SatEnv(mem_mb=mem_mb, region_kb=region_kb, seed=seed)

    a = [1.0] * env.num_actions()
    b = [1.0] * env.num_actions()

    def calculate_reward(res: StepResult, first_before: bool) -> float:
        r = 0.0
        # Priority 1: UEs (System Crashers)
        if res.ue_count > 0: r += 1000.0  
        # Priority 2: CEs
        elif res.ce_count > 0: r += 10.0   
        # Priority 3: Discovery
        r += 20.0 * res.new_sigs
        # Priority 4: Speed (TTFF)
        if res.errors > 0 and first_before: r += 200.0
        # Efficiency
        r -= 1e-5 * res.dt
        return r

    print(f"[train] Starting {episodes} episodes on {env.num_actions()} GSAT variants...")
    
    for ep in range(episodes):
        env.reset(fault_seed=ep, cfg_override=cfg_override)
        for _ in range(steps):
            scores = [rng.betavariate(a[i], b[i]) for i in range(env.num_actions())]
            aid = scores.index(max(scores))

            before = (env.first_error_time is None)
            res = env.step(aid)
            rew = calculate_reward(res, before)

            if rew > 0:
                a[aid] += 1.0 
                if res.ue_count > 0: a[aid] += 10.0 
            else:
                b[aid] += 1.0

    means = [a[i] / (a[i] + b[i]) for i in range(env.num_actions())]
    ranked = sorted(range(env.num_actions()), key=lambda i: means[i], reverse=True)

    policy = {
        "actions": ranked[:20],
        "top_scores": {env.sat_vars[i]['variant_name']: means[i] for i in ranked[:10]}
    }
    
    with open(out_path, "w") as f:
        json.dump(policy, f, indent=2)

    print(f"[train] Policy saved to {out_path}")
    print("[train] Top 5 Patterns:")
    for i in ranked[:5]:
        print(f"  {env.sat_vars[i]['variant_name']} (Score: {means[i]:.3f})")

# ----------------------------
# 6. Evaluation & Comparison
# ----------------------------

def run_evaluation(name, env, action_strategy: Callable[[int, int], int], episodes, steps, cfg_override=None) -> dict:
    tot_ue, tot_ce = 0, 0
    ttff_list = []
    global_sigs = set()
    
    for ep in range(episodes):
        eval_seed = ep + 2000 
        env.reset(fault_seed=eval_seed, cfg_override=cfg_override) 

        for s in range(steps):
            aid = action_strategy(s, env.num_actions())
            res = env.step(aid)
            tot_ue += res.ue_count
            tot_ce += res.ce_count
        
        if env.first_error_time is not None:
            ttff_list.append(env.first_error_time)
        global_sigs.update(env.seen_sigs)

    failures = len(ttff_list)
    avg_ttff = sum(ttff_list) / failures if failures > 0 else 0.0
    
    return {
        "name": name, "ce": tot_ce, "ue": tot_ue, "coverage": len(global_sigs),
        "failures": failures, "ttff": avg_ttff
    }

def print_comparison_table(results: List[dict]):
    print("\n" + "="*100)
    print(f"{'STRATEGY':<15} | {'FAILURES (Ep)':<15} | {'COVERAGE (Sigs)':<15} | {'UE COUNT':<10} | {'AVG TTFF (Ticks)':<20}")
    print("-" * 100)
    
    base = next((r for r in results if r['name'] == 'Sequential'), results[0])
    
    for r in results:
        ttff_imp = f"{base['ttff'] / r['ttff']:.1f}x" if r['ttff'] > 0 and base['ttff'] > 0 else "-"
        if r['name'] == base['name']: ttff_imp = "1.0x"
        print(f"{r['name']:<15} | {r['failures']:<15} | {r['coverage']:<15} | {r['ue']:<10} | {r['ttff']:<10.1f} ({ttff_imp})")
    print("="*100 + "\n")

# ----------------------------
# 7. Main CLI
# ----------------------------

def parse_cfg(args) -> dict:
    d = {}
    if args.stuck_prob: d["stuck_prob"] = args.stuck_prob
    if args.burst_prob: d["burst_prob"] = args.burst_prob
    if args.hammer_threshold: d["hammer_threshold"] = args.hammer_threshold
    return d

def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)

    def add_args(parser):
        parser.add_argument("--mem-mb", type=int, default=64)
        parser.add_argument("--region-kb", type=int, default=16)
        parser.add_argument("--episodes", type=int, default=50)
        parser.add_argument("--steps", type=int, default=5)
        parser.add_argument("--seed", type=int, default=0)
        parser.add_argument("--stuck-prob", type=float, default=None)
        parser.add_argument("--burst-prob", type=float, default=None)
        parser.add_argument("--hammer-threshold", type=int, default=None)

    p_train = sub.add_parser("train")
    add_args(p_train)
    p_train.add_argument("--out", default="policy.json")

    p_eval = sub.add_parser("eval")
    add_args(p_eval)
    p_eval.add_argument("--policy", required=True)

    p_base = sub.add_parser("baseline")
    add_args(p_base)

    p_comp = sub.add_parser("compare")
    add_args(p_comp)
    p_comp.add_argument("--policy", required=True)

    args = p.parse_args()
    cfg = parse_cfg(args)

    if args.cmd == "train":
        bandit_train(args.episodes, args.steps, args.mem_mb, args.region_kb, 
                     args.seed, args.out, cfg)
    
    elif args.cmd == "compare":
        with open(args.policy) as f:
            pol_actions = json.load(f)["actions"]
        env = SatEnv(args.mem_mb, args.region_kb, args.seed)
        
        strategies = [
            ("Sequential", lambda step, n: step % n),
            ("Random", lambda step, n: random.randrange(n)),
            ("RL_Agent", lambda step, n: pol_actions[step % len(pol_actions)])
        ]
        
        results = []
        print(f"Comparing strategies over {args.episodes} episodes...")
        for name, strat in strategies:
            r = run_evaluation(name, env, strat, args.episodes, args.steps, cfg)
            results.append(r)
        print_comparison_table(results)

    elif args.cmd == "eval":
        with open(args.policy) as f:
            actions = json.load(f)["actions"]
        env = SatEnv(args.mem_mb, args.region_kb, 0)
        strat = lambda step, n: actions[step % len(actions)]
        r = run_evaluation("Eval", env, strat, args.episodes, args.steps, cfg)
        print(f"[eval] CE: {r['ce']}, UE: {r['ue']}, Coverage: {r['coverage']}, Avg TTFF: {r['ttff']:.1f}")

    elif args.cmd == "baseline":
        env = SatEnv(args.mem_mb, args.region_kb, 0)
        strat = lambda step, n: random.randrange(n)
        r = run_evaluation("Baseline", env, strat, args.episodes, args.steps, cfg)
        print(f"[baseline] CE: {r['ce']}, UE: {r['ue']}, Coverage: {r['coverage']}, Avg TTFF: {r['ttff']:.1f}")

if __name__ == "__main__":
    main()