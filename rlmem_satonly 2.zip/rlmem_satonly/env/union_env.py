
from dataclasses import dataclass
from backend.numpy_backend import NumpyFaultBackend
from backend.fault_models import FaultModel, FaultConfig
from sat_patterns.sat_catalog import variants
from sat_patterns.sat_runner import sat_fill_verify

@dataclass
class StepResult:
    dt: int
    errors: int
    new_sigs: int
    first_error_time: int | None

class UnionEnv:
    def __init__(self, mem_bytes=256*1024*1024):
        self.mem_bytes = mem_bytes
        self.reset()

    def reset(self, seed=0):
        self.fault = FaultModel(FaultConfig(seed=seed), self.mem_bytes//4)
        self.backend = NumpyFaultBackend(self.mem_bytes, self.fault)
        self.sat = variants()
        self.seen = set()
        self.first_error_time = None

    def num_actions(self): return len(self.sat)

    def step(self, aid):
        t0 = self.backend.time
        v = self.sat[aid]
        errs = sat_fill_verify(self.backend, 0, self.mem_bytes//8,
                               v["vals"], v["busshift"], v["invert"])
        new = 0
        for e in errs:
            sig = (e.fault_type, e.addr//4096, e.bitmask & 0xff)
            if sig not in self.seen:
                self.seen.add(sig); new += 1
        if errs and self.first_error_time is None:
            self.first_error_time = self.backend.time
        return StepResult(self.backend.time - t0, len(errs), new,
                          self.first_error_time)
