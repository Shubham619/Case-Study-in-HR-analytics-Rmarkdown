#!/bin/bash
set -e

# 1. Check Dependencies
if command -v brew &> /dev/null; then
    BREW_PREFIX=$(brew --prefix)
else
    echo "[Error] Homebrew required."
    exit 1
fi

mkdir -p build

# 2. Compile Bridge (C++ Logic)
echo "[Build] Compiling Bridge..."
g++ -c -fPIC -o build/bridge.o src/bridge.cpp \
    -I ramulator2/src \
    -I"$BREW_PREFIX/include" \
    -std=c++17 -O3

# 3. Compile Wrapper (C Interface)
echo "[Build] Compiling Wrapper..."
g++ -c -fPIC -o build/wrapper.o src/wrapper.cpp \
    -std=c++17 -O3

# 4. Link
echo "[Build] Linking..."
g++ -shared -fPIC -o build/libramulator_wrapper.so \
    build/bridge.o \
    build/wrapper.o \
    -L"$BREW_PREFIX/lib" \
    -L. -lramulator2 \
    -undefined dynamic_lookup

echo "[Success] Built: build/libramulator_wrapper.so"